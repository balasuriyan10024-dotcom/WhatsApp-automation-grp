package com.wa.auto
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** start = midnight of first date; runs for `days` days from it, at hour:min, on weekdays in mask (bit0=Sun..bit6=Sat, 0 = every day). */
data class Job(val id: Int, val start: Long, val hour: Int, val min: Int, val days: Int, val mask: Int,
               val numbers: List<String>, val groups: List<String>, val msg: String) {
    fun next(after: Long): Long? {
        val c = Calendar.getInstance()
        for (d in 0 until days) {
            c.timeInMillis = start; c.add(Calendar.DAY_OF_YEAR, d)
            c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, min); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            val ok = mask == 0 || ((mask shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1) == 1
            if (ok && c.timeInMillis > after) return c.timeInMillis
        }
        return null
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", 0)
    fun rules(c: Context): List<Pair<String, String>> {
        val a = JSONArray(p(c).getString("rules", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("k") to o.getString("r") } }
    }
    fun saveRules(c: Context, l: List<Pair<String, String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("k", it.first).put("r", it.second)) }
        p(c).edit().putString("rules", a.toString()).apply()
    }
    private fun list(a: JSONArray) = (0 until a.length()).map { a.getString(it) }
    fun jobs(c: Context): List<Job> {
        val a = JSONArray(p(c).getString("jobs2", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Job(o.getInt("id"), o.getLong("s"), o.getInt("h"), o.getInt("mi"), o.getInt("d"), o.getInt("w"),
                list(o.getJSONArray("n")), list(o.getJSONArray("g")), o.getString("m"))
        }
    }
    fun saveJobs(c: Context, l: List<Job>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("s", it.start).put("h", it.hour).put("mi", it.min)
            .put("d", it.days).put("w", it.mask).put("n", JSONArray(it.numbers)).put("g", JSONArray(it.groups)).put("m", it.msg)) }
        p(c).edit().putString("jobs2", a.toString()).apply()
    }
}
