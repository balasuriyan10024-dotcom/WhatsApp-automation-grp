package com.wa.auto
import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

object Sched {
    private fun pi(c: Context, id: Int) = PendingIntent.getBroadcast(c, id,
        Intent(c, Alarm::class.java).putExtra("id", id), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    fun set(c: Context, id: Int, time: Long) = c.getSystemService(AlarmManager::class.java)
        .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi(c, id))
    fun cancel(c: Context, id: Int) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
}

class Alarm : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val jobs = Store.jobs(c)
        val now = System.currentTimeMillis()
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            jobs.forEach { j -> j.next(now)?.let { Sched.set(c, j.id, it) } }; return
        }
        val j = jobs.find { it.id == i.getIntExtra("id", -1) } ?: return
        Sender.start(c, j)
        val n = j.next(now + 1000)
        if (n != null) Sched.set(c, j.id, n) else Store.saveJobs(c, jobs - j)
    }
}

data class Target(val group: Boolean, val v: String, val msg: String)

/** Sends queued messages one by one; SendService does the tapping inside WhatsApp. */
object Sender {
    private val q = ArrayDeque<Target>()
    private var token = 0
    @Volatile var waiting = false
    @Volatile var state = 0
    @Volatile var cur: Target? = null
    fun pkg(c: Context) = try { c.packageManager.getPackageInfo("com.whatsapp", 0); "com.whatsapp" } catch (e: Exception) { "com.whatsapp.w4b" }
    fun start(c: Context, j: Job) {
        j.numbers.forEach { q.add(Target(false, it, j.msg)) }
        j.groups.forEach { q.add(Target(true, it, j.msg)) }
        if (!waiting) next(c)
    }
    fun next(c: Context) {
        val t = q.removeFirstOrNull() ?: run { waiting = false; cur = null; return }
        cur = t; state = 0; waiting = true
        val tk = ++token
        val i = if (t.group) Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.msg)
        else Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${t.v}?text=${Uri.encode(t.msg)}"))
        c.startActivity(i.setPackage(pkg(c)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Handler(Looper.getMainLooper()).postDelayed({ if (waiting && tk == token) next(c) }, 30000) // skip if stuck
    }
}

class SendService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())

    private fun find(n: AccessibilityNodeInfo?, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (p(n)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), p)?.let { return it }
        return null
    }
    private fun click(n: AccessibilityNodeInfo) {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        x?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
    private fun isSend(n: AccessibilityNodeInfo) = n.viewIdResourceName?.endsWith(":id/send") == true ||
        n.contentDescription?.toString().equals("Send", true) || (n.text?.toString().equals("Send", true) && n.isClickable)
    private fun isEdit(n: AccessibilityNodeInfo) = n.className?.toString() == "android.widget.EditText"

    /** Direct number chat: just tap Send. */
    private fun numberStep(root: AccessibilityNodeInfo): Boolean {
        val b = find(root) { it.viewIdResourceName == "${Sender.pkg(this)}:id/send" } ?: return false
        click(b); return true
    }
    /** Group: share screen -> search -> type group name -> tap group -> tap Send. */
    private fun groupStep(root: AccessibilityNodeInfo, name: String): Boolean {
        when (Sender.state) {
            0 -> {
                if (find(root, this::isEdit) != null) { Sender.state = 1; return false }
                val s = find(root) { it.contentDescription?.toString().equals("Search", true) } ?: return false
                click(s); Sender.state = 1
            }
            1 -> {
                val e = find(root, this::isEdit) ?: return false
                val a = Bundle(); a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, name)
                e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a); Sender.state = 2
            }
            2 -> {
                val t = find(root) { !isEdit(it) && it.text?.toString()?.trim().equals(name.trim(), true) } ?: return false
                click(t); Sender.state = 3
            }
            3 -> {
                val b = find(root, this::isSend) ?: return false
                click(b); return true
            }
        }
        return false
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!Sender.waiting) return
        val t = Sender.cur ?: return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val done = if (t.group) groupStep(root, t.v) else numberStep(root)
        if (done) {
            Sender.waiting = false
            h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); h.postDelayed({ Sender.next(this) }, 1500) }, 2000)
        }
    }
    override fun onInterrupt() {}
}
