package com.wa.auto
import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.app.RemoteInput
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Auto-reply: matches incoming WhatsApp text (case-insensitive) against your rules. */
class ReplyService : NotificationListenerService() {
    private val seen = HashMap<String, Long>()
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        if (ex.getBoolean("android.isGroupConversation")) return
        val text = ex.getCharSequence("android.text")?.toString() ?: return
        if (seen[sbn.key] == n.`when`) return
        seen[sbn.key] = n.`when`
        val rule = Store.rules(this).firstOrNull { text.contains(it.first.trim(), ignoreCase = true) } ?: return
        val act = n.actions?.firstOrNull { !it.remoteInputs.isNullOrEmpty() } ?: return
        val ri = act.remoteInputs[0]
        val i = Intent(); val b = Bundle()
        b.putCharSequence(ri.resultKey, rule.second)
        RemoteInput.addResultsToIntent(arrayOf(ri), i, b)
        try { act.actionIntent.send(this, 0, i) } catch (_: Exception) {}
    }
}
