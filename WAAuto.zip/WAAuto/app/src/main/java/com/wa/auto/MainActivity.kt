package com.wa.auto
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var pDate = 0L; private var pH = -1; private var pM = 0
    private val dfmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        setContentView(ScrollView(this).apply { addView(root) })
        draw()
    }
    private fun tv(t: String) = TextView(this).apply { text = t; textSize = 17f; setPadding(0, 32, 0, 8) }
    private fun et(h: String) = EditText(this).apply { hint = h }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }

    private fun draw() {
        root.removeAllViews()
        root.addView(tv("1. Permissions (enable all three)"))
        root.addView(btn("Notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        root.addView(btn("Accessibility (WA Auto)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("Display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(tv("2. Auto-replies (tap one to delete)"))
        Store.rules(this).forEachIndexed { i, r ->
            root.addView(btn("\"${r.first}\"  →  \"${r.second}\"") {
                Store.saveRules(this, Store.rules(this).filterIndexed { x, _ -> x != i }); draw()
            })
        }
        val k = et("If message contains (any case)"); val r = et("Reply with")
        root.addView(k); root.addView(r)
        root.addView(btn("Add reply rule") {
            if (k.text.isNotBlank() && r.text.isNotBlank()) {
                Store.saveRules(this, Store.rules(this) + (k.text.toString().trim() to r.text.toString())); draw()
            }
        })

        root.addView(tv("3. Scheduled messages (tap one to cancel)"))
        val dn = arrayOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")
        Store.jobs(this).forEach { j ->
            val wd = if (j.mask == 0) "every day" else dn.filterIndexed { i, _ -> (j.mask shr i) and 1 == 1 }.joinToString(" ")
            val nx = j.next(System.currentTimeMillis())?.let { fmt.format(Date(it)) } ?: "done"
            root.addView(btn("Next: $nx\n$wd, ${j.days} day(s) from ${dfmt.format(Date(j.start))}\n${j.numbers.size} number(s), ${j.groups.size} group(s): ${j.msg}") {
                Sched.cancel(this, j.id); Store.saveJobs(this, Store.jobs(this) - j); draw()
            })
        }
        val nums = et("Numbers with country code, comma separated (optional)")
        val grp = et("Group names exactly as in WhatsApp, comma separated (optional)")
        val msg = et("Message")
        val dBtn = btn(if (pDate > 0) dfmt.format(Date(pDate)) else "Pick start date") {}
        val tBtn = btn(if (pH >= 0) String.format("%02d:%02d", pH, pM) else "Pick time") {}
        dBtn.setOnClickListener {
            val c = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                c.set(y, m, d, 0, 0, 0); c.set(Calendar.MILLISECOND, 0); pDate = c.timeInMillis; dBtn.text = dfmt.format(c.time)
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        tBtn.setOnClickListener {
            val c = Calendar.getInstance()
            TimePickerDialog(this, { _, hh, mm -> pH = hh; pM = mm; tBtn.text = String.format("%02d:%02d", hh, mm) },
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }
        val days = et("Number of days (1 = only the start date)").apply { inputType = 2; setText("1") }
        val row = LinearLayout(this)
        val cbs = dn.map { d -> CheckBox(this).apply { text = d; textSize = 12f; row.addView(this) } }
        root.addView(nums); root.addView(grp); root.addView(msg); root.addView(dBtn); root.addView(tBtn)
        root.addView(days); root.addView(tv("Repeat only on (none ticked = every day):")); root.addView(row)
        root.addView(btn("Schedule") {
            val ns = nums.text.split(",").map { it.filter(Char::isDigit) }.filter { it.length >= 8 }
            val gs = grp.text.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val nd = days.text.toString().toIntOrNull() ?: 1
            val mask = cbs.foldIndexed(0) { i, a, cb -> if (cb.isChecked) a or (1 shl i) else a }
            if ((ns.isEmpty() && gs.isEmpty()) || msg.text.isBlank() || pDate <= 0 || pH < 0 || nd < 1) {
                Toast.makeText(this, "Add numbers or groups, a message, start date, time and days", Toast.LENGTH_LONG).show()
            } else {
                val j = Job((System.currentTimeMillis() / 1000).toInt(), pDate, pH, pM, nd, mask, ns, gs, msg.text.toString())
                val n = j.next(System.currentTimeMillis())
                if (n == null) Toast.makeText(this, "No upcoming matching day/time in that range", Toast.LENGTH_LONG).show()
                else { Store.saveJobs(this, Store.jobs(this) + j); Sched.set(this, j.id, n); pDate = 0; pH = -1; draw() }
            }
        })
    }
}
